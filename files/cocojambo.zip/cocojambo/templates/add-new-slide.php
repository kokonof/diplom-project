<div class="wrap">
	<h2>
		<?php _e('Set Slide','cocojambo'); ?>
	</h2>

	<table class="wp-list-table widefat fixed striped table-view-list posts">
		<thead>
		<tr>
			<th class="manage-column column-title column-primary"
			    style="width: 50%;"><?php _e( 'Title', 'wfmpanel' ); ?></th>
			<th class="manage-column column-categories" style="width: 50%;"><?php _e( 'Slide', 'wfmpanel' ); ?></th>
		</tr>
		</thead>
		<tbody>

		<?php /** @var Cocojambo_Admin $posts */
		if ( $posts->have_posts() ) : while ( $posts->have_posts() ) : $posts->the_post(); ?>
			<tr>
				<td class="title column-title has-row-actions column-primary page-title"
				    data-colname="<?php _e( 'Title', 'wfmpanel' ); ?>">
					<a href="<?php the_permalink(); ?>"><?php the_title() ?></a>
					<button type="button" class="toggle-row"><span
							class="screen-reader-text"><?php _e( 'Show more details', 'wfmpanel' ); ?></span>
					</button>
				</td>
				<td class="column-slides" data-colname="<?php _e( 'Slides', 'wfmpanel' ); ?>">
					<select name="" id="">
						<option value="">Lorem ipsum dolor sit amet.</option>
						<option value="">Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet.</option>
						<option value="">Lorem ipsum dolor sit amet.</option>
					</select>
				</td>
			</tr>
		<?php endwhile; else : ?>
			<p><?php _e( 'No entries found', 'wfmpanel' ) ?></p>
		<?php endif; ?>

		</tbody>
	</table>
</div>
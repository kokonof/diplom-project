<div id="slidebox">
	<p class="slide-title">
		<?php echo $slide['title'] ?>
		<small>
			<a href="#" id="close">✕</a>
		</small>
	</p>
	<div>
		<?php echo $slide['content'] ?>
	</div>

    <a href="<?php echo $slide['url'] ?>"
       class="btn btn-outline-success" style="width: 100%"> Читати далі >>></a>
</div>
